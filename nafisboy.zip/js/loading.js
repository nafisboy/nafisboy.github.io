function showLoading() {
    var loading = document.getElementById('loading');
    loading.style.display = 'block';

    // Simulating a task that takes 3 seconds
    setTimeout(function() {
        loading.style.display = 'none';
    }, 3000);
}
function showLoading() {
    var loading = document.getElementById('container');
    loading.style.display = 'block';

    // Simulating a task that takes 3 seconds
    setTimeout(function() {
        loading.style.display = 'none';
    }, 3000);
}